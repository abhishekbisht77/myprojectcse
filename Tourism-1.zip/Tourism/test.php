<?php
include 'dbconnect.php';
if ($conn && !$conn->connect_error) {
    echo "Connected successfully as tourism_user!";
} else {
    echo "Connection failed: ";
    if (isset($conn->connect_error)) echo $conn->connect_error;
}
?>