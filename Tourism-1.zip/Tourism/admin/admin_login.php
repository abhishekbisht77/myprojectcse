<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) session_start();

include(__DIR__ . '/../dbconnect.php');

if (isset($_SESSION['admin_email'])) {
    header('Location: admin_dashboard.php');
    exit();
}

$loginError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $loginError = "Please fill both fields.";
    } else {
        $stmt = $conn->prepare("SELECT id, email, password, name FROM admins WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows > 0) {
            $row = $res->fetch_assoc();
            $stored = $row['password'];

            // Prefer password_verify if it is a hash created by password_hash
            $verified = false;
            if (password_verify($password, $stored)) {
                $verified = true;
            } else {
                // fallback: direct compare (in case DB stored hashed string or plain)
                if ($password === $stored) $verified = true;
            }

            if ($verified) {
                $_SESSION['admin_email'] = $row['email'];
                $_SESSION['admin_name'] = $row['name'] ?? '';
                header('Location: admin_dashboard.php');
                exit();
            } else {
                $loginError = "Invalid email or password.";
            }
        } else {
            $loginError = "No admin account found for this email.";
        }
        $stmt->close();
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin Login</title>
  <style>
    /* small styling */
    body{font-family:Arial;background:#f3f6fa;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
    .card{background:#fff;padding:30px;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,0.08);width:360px}
    input{width:100%;padding:10px;margin:8px 0;border-radius:6px;border:1px solid #ccc}
    button{width:100%;padding:10px;border-radius:6px;border:none;background:#0078ff;color:#fff;font-weight:600}
    .error{background:#dc3545;color:#fff;padding:10px;border-radius:6px;margin-bottom:10px;text-align:center}
  </style>
</head>
<body>
  <div class="card">
    <h2 style="text-align:center;margin:0 0 12px">Admin Login</h2>
    <?php if($loginError): ?><div class="error"><?php echo htmlspecialchars($loginError); ?></div><?php endif; ?>
    <form method="post">
      <input type="email" name="email" placeholder="Admin Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
