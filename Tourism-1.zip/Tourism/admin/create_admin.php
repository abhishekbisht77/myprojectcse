<?php

if (php_sapi_name() !== 'cli') {
    // web request ok
}
include(__DIR__ . '/../dbconnect.php');

$email = 'admin@gmail.com';
$password = 'admin123';
$name = 'Default Admin';

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO admins (email, password, name) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $hash, $name);
if ($stmt->execute()) {
    echo "Admin created: $email";
} else {
    echo "Error creating admin: " . $stmt->error;
}
$stmt->close();
