<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) session_start();
include(__DIR__ . '/../dbconnect.php');

if (!isset($_SESSION['admin_email'])) {
    header('Location: admin_login.php');
    exit();
}

// Helper: simple query list fetch
function fetch_all($conn, $sql) {
    $arr = [];
    $res = $conn->query($sql);
    if ($res) while ($r = $res->fetch_assoc()) $arr[] = $r;
    return $arr;
}

// Delete user
if (isset($_GET['delete_user'])) {
    $id = intval($_GET['delete_user']);
    $conn->query("DELETE FROM users WHERE id=$id");
    header('Location: admin_dashboard.php?tab=users');
    exit();
}

// Delete booking
if (isset($_GET['delete_booking'])) {
    $id = intval($_GET['delete_booking']);
    $conn->query("DELETE FROM bookings WHERE id=$id");
    header('Location: admin_dashboard.php?tab=bookings');
    exit();
}

// Change booking status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
    $bid = intval($_POST['booking_id']);
    $new = $conn->real_escape_string($_POST['status']);
    $conn->query("UPDATE bookings SET status='$new' WHERE id=$bid");
    header('Location: admin_dashboard.php?tab=bookings');
    exit();
}

// Delete destination
if (isset($_GET['delete_dest'])) {
    $id = intval($_GET['delete_dest']);
    $conn->query("DELETE FROM destinations WHERE id=$id");
    header('Location: admin_dashboard.php?tab=destinations');
    exit();
}

// Fetch lists
$users = fetch_all($conn, "SELECT * FROM users ORDER BY id DESC");
$bookings = fetch_all($conn, "SELECT * FROM bookings ORDER BY id DESC");
$destinations = fetch_all($conn, "SELECT * FROM destinations ORDER BY id ASC");

// Optional payments
$payments = [];
$hasPayments = ($conn->query("SHOW TABLES LIKE 'payments'")->num_rows > 0);
if ($hasPayments) $payments = fetch_all($conn, "SELECT * FROM payments ORDER BY id DESC");

// Counts
$totalUsers = intval($conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'] ?? 0);
$totalBookings = intval($conn->query("SELECT COUNT(*) as c FROM bookings")->fetch_assoc()['c'] ?? 0);
$totalDest = intval($conn->query("SELECT COUNT(*) as c FROM destinations")->fetch_assoc()['c'] ?? 0);
$totalPayments = $hasPayments ? intval($conn->query("SELECT COUNT(*) as c FROM payments")->fetch_assoc()['c'] ?? 0) : 0;

$tab = $_GET['tab'] ?? 'dashboard';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Dashboard</title>
<style>
body{font-family:Arial;margin:0;display:flex;background:#f4f6f9}
.sidebar{width:240px;background:#1a73e8;color:#fff;min-height:100vh;padding:20px 0}
.sidebar h2{text-align:center;margin:0 0 18px}
.sidebar a{display:block;color:#fff;padding:12px 20px;text-decoration:none}
.sidebar a.active{background:#155cb0}
.main{flex:1;padding:20px}
.header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
.card{display:flex;gap:16px;margin-bottom:18px}
.card .c{background:#fff;padding:18px;border-radius:8px;box-shadow:0 1px 5px rgba(0,0,0,0.08);min-width:140px;text-align:center}
.table{background:#fff;border-collapse:collapse;width:100%;box-shadow:0 1px 5px rgba(0,0,0,0.06)}
.table th,.table td{padding:10px;border-bottom:1px solid #eee;text-align:left}
.table th{background:#f8f9fa}
.btn{padding:6px 10px;border-radius:6px;border:none;cursor:pointer}
.btn.del{background:#dc3545;color:#fff}
.btn.edit{background:#ffc107}
</style>
</head>
<body>
  <div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="?tab=dashboard" class="<?php echo $tab==='dashboard'?'active':'';?>">Dashboard</a>
    <a href="?tab=users" class="<?php echo $tab==='users'?'active':'';?>">Users</a>
    <a href="?tab=bookings" class="<?php echo $tab==='bookings'?'active':'';?>">Bookings</a>
    <a href="?tab=destinations" class="<?php echo $tab==='destinations'?'active':'';?>">Destinations</a>
    <?php if($hasPayments): ?><a href="?tab=payments" class="<?php echo $tab==='payments'?'active':'';?>">Payments</a><?php endif; ?>
    <a href="logout.php">Logout</a>
  </div>

  <div class="main">
    <div class="header">
      <div>
        <h1 style="margin:0">Welcome <?php echo htmlspecialchars($_SESSION['admin_name'] ?? $_SESSION['admin_email']); ?></h1>
      </div>
      <div>
        <strong><?php echo htmlspecialchars($_SESSION['admin_email']); ?></strong>
      </div>
    </div>

    <?php if($tab==='dashboard'): ?>
      <div class="card">
        <div class="c"><h3><?php echo $totalUsers;?></h3><div>Users</div></div>
        <div class="c"><h3><?php echo $totalBookings;?></h3><div>Bookings</div></div>
        <div class="c"><h3><?php echo $totalDest;?></h3><div>Destinations</div></div>
        <?php if($hasPayments): ?><div class="c"><h3><?php echo $totalPayments;?></h3><div>Payments</div></div><?php endif; ?>
      </div>
    <?php endif; ?>

    <?php if($tab==='users'): ?>
      <h2>All Users</h2>
      <table class="table">
        <tr>
          <?php if(!empty($users)): foreach(array_keys($users[0]) as $col): ?><th><?php echo ucfirst($col);?></th><?php endforeach; endif;?>
          <th>Action</th>
        </tr>
        <?php foreach($users as $u): ?>
          <tr>
            <?php foreach($u as $v): ?><td><?php echo htmlspecialchars($v);?></td><?php endforeach; ?>
            <td><a class="btn del" href="?delete_user=<?php echo intval($u['id']);?>" onclick="return confirm('Delete user?')">Delete</a></td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>

    <?php if($tab==='bookings'): ?>
      <h2>All Bookings</h2>
      <table class="table">
        <tr>
          <?php if(!empty($bookings)): foreach(array_keys($bookings[0]) as $col): ?><th><?php echo ucfirst($col);?></th><?php endforeach; endif;?>
          <th>Actions</th>
        </tr>
        <?php foreach($bookings as $b): ?>
          <tr>
            <?php foreach($b as $v): ?><td><?php echo htmlspecialchars($v);?></td><?php endforeach; ?>
            <td>
              <form method="post" style="display:inline-block">
                <input type="hidden" name="booking_id" value="<?php echo intval($b['id']); ?>">
                <select name="status">
                  <option <?php if(($b['status']??'')==='pending') echo 'selected';?>>pending</option>
                  <option <?php if(($b['status']??'')==='approved') echo 'selected';?>>approved</option>
                  <option <?php if(($b['status']??'')==='cancelled') echo 'selected';?>>cancelled</option>
                </select>
                <button class="btn" name="change_status" type="submit">Update</button>
              </form>
              <a class="btn del" href="?delete_booking=<?php echo intval($b['id']);?>" onclick="return confirm('Delete booking?')">Delete</a>
            </td>
          </tr>
        <?php endforeach;?>
      </table>
    <?php endif; ?>

    <?php if($tab==='destinations'): ?>
      <h2>Destinations</h2>
      <table class="table">
        <tr>
          <?php if(!empty($destinations)): foreach(array_keys($destinations[0]) as $col): ?><th><?php echo ucfirst($col);?></th><?php endforeach; endif;?>
          <th>Action</th>
        </tr>
        <?php foreach($destinations as $d): ?>
          <tr>
            <?php foreach($d as $v): ?><td><?php echo htmlspecialchars($v);?></td><?php endforeach; ?>
            <td><a class="btn del" href="?delete_dest=<?php echo intval($d['id']);?>" onclick="return confirm('Delete destination?')">Delete</a></td>
          </tr>
        <?php endforeach;?>
      </table>
    <?php endif; ?>

    <?php if($tab==='payments' && $hasPayments): ?>
      <h2>Payments</h2>
      <table class="table">
        <tr><?php if(!empty($payments)): foreach(array_keys($payments[0]) as $col): ?><th><?php echo ucfirst($col);?></th><?php endforeach; endif;?><th>Action</th></tr>
        <?php foreach($payments as $p): ?>
          <tr>
            <?php foreach($p as $v): ?><td><?php echo htmlspecialchars($v);?></td><?php endforeach; ?>
            <td></td>
          </tr>
        <?php endforeach;?>
      </table>
    <?php endif; ?>

  </div>
</body>
</html>
