<?php
session_start();
include(__DIR__ . '/../dbconnect.php');


if (!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit();
}


$id = isset($_GET['id']) ? intval($_GET['id']) : 0;


$stmt = $conn->prepare("SELECT * FROM destinations WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$destination = $result->fetch_assoc();

if (!$destination) {
    die("Destination not found!");
}


$destinationMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);

    if ($name && $price >= 0) {
        $stmt = $conn->prepare("UPDATE destinations SET name=?, description=?, price=? WHERE id=?");
        $stmt->bind_param("ssdi", $name, $description, $price, $id);
        if ($stmt->execute()) {
           
            header("Location: admin_dashboard.php?msg=Destination+updated+successfully");
            exit();
        } else {
            $destinationMsg = "Error updating destination!";
        }
    } else {
        $destinationMsg = "Name and valid Price are required!";
    }
}
?>

<?php include(__DIR__ . '/../includes/header.php'); ?>

<div class="container" style="max-width:600px; margin-top:30px;">
    <h2>Edit Destination</h2>

    <?php if ($destinationMsg): ?>
        <p style="color:red; font-weight:500;"><?php echo htmlspecialchars($destinationMsg); ?></p>
    <?php endif; ?>

    <form method="POST" style="display:flex; flex-direction:column; gap:10px;">
        <input type="text" name="name" placeholder="Destination Name" value="<?php echo htmlspecialchars($destination['name']); ?>" required style="padding:10px; border-radius:6px; border:1px solid #ccc;">
        <textarea name="description" placeholder="Description" rows="4" style="padding:10px; border-radius:6px; border:1px solid #ccc;"><?php echo htmlspecialchars($destination['description']); ?></textarea>
        <input type="number" name="price" placeholder="Price" step="0.01" value="<?php echo htmlspecialchars($destination['price']); ?>" required style="padding:10px; border-radius:6px; border:1px solid #ccc;">
        <button type="submit" style="background:#0078ff; color:white; border:none; padding:10px; border-radius:6px; cursor:pointer;">Update Destination</button>
    </form>

    <a href="admin_dashboard.php" style="display:inline-block; margin-top:15px; text-decoration:none; color:#0078ff;">← Back to Dashboard</a>
</div>

<?php include(__DIR__ . '/../includes/footer.php'); ?>
