
-- SMART TOURIST MANAGEMENT SYSTEM

CREATE DATABASE IF NOT EXISTS tourism_project;
USE tourism_project;


CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fullname VARCHAR(100) NOT NULL,
  mobile VARCHAR(20),
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO users (fullname, mobile, email, password) VALUES
('Test User', '9876543210', 'testuser@gmail.com', '$2y$10$2z9LzDjFvNfUOSVxRZsxMupfPQ3y13ucKMEv1oYb1Dk1zCq1wFpfa'); 
-- password = test123 (hashed)



CREATE TABLE IF NOT EXISTS destinations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL
);

INSERT IGNORE INTO destinations (name, description, price) VALUES
('Goa', 'Beaches and nightlife', 3000),
('Delhi', 'Capital city with heritage sites', 2000),
('Sikkim', 'Peaceful hill state', 3500),
('Agra', 'Home of the Taj Mahal', 2500),
('Hyderabad', 'City of pearls', 3000);


CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  fullname VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(20),
  destination VARCHAR(100),
  start_date DATE,
  end_date DATE,
  price DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

INSERT IGNORE INTO bookings (user_id, fullname, email, phone, destination, start_date, end_date, price, status) VALUES
(1, 'Test User', 'testuser@gmail.com', '9876543210', 'Goa', '2025-12-01', '2025-12-04', 9000, 'pending');


CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT,
  amount DECIMAL(10,2),
  method VARCHAR(50),
  status VARCHAR(20),
  txn_id VARCHAR(100),
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- Default admin account (email: admin@gmail.com / password: admin123)
INSERT IGNORE INTO admins (name, email, password) VALUES
('Administrator', 'admin@gmail.com', '$2y$10$YbKZDTKQbQK6pPn4QHPXcu4k3ko4ZLRxtIuWkldM9gk6M3bAKF2fK');

CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  rating INT CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
