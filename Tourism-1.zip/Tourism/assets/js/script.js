// Simulated DB
let users = [];
let currentUser = null;

let destinations = [
    {name:'Paris', location:'France', cost:1200, duration:5, img:'https://source.unsplash.com/250x150/?paris'},
    {name:'Tokyo', location:'Japan', cost:1500, duration:7, img:'https://source.unsplash.com/250x150/?tokyo'},
    {name:'New York', location:'USA', cost:1000, duration:4, img:'https://source.unsplash.com/250x150/?newyork'},
    {name:'Sydney', location:'Australia', cost:1800, duration:6, img:'https://source.unsplash.com/250x150/?sydney'}
];

// ---------------- AUTH ----------------
document.addEventListener('DOMContentLoaded', () => {
    // Register
    const registerForm = document.getElementById('registerForm');
    if(registerForm){
        registerForm.addEventListener('submit', (e)=>{
            e.preventDefault();
            const formData = new FormData(registerForm);
            const user = {
                name: formData.get('name'),
                email: formData.get('email'),
                password: formData.get('password'),
                phone: formData.get('phone')
            };
            users.push(user);
            alert('Registered Successfully!');
            window.location.href = 'login.html';
        });
    }

    // Login
    const loginForm = document.getElementById('loginForm');
    if(loginForm){
        loginForm.addEventListener('submit', (e)=>{
            e.preventDefault();
            const formData = new FormData(loginForm);
            const email = formData.get('email');
            const password = formData.get('password');
            const user = users.find(u => u.email === email && u.password === password);
            if(user){
                currentUser = user;
                alert('Login Successful!');
                window.location.href = 'index.html';
            } else {
                alert('Invalid credentials!');
            }
        });
    }

    // Profile
    const profileForm = document.getElementById('profileForm');
    if(profileForm && currentUser){
        profileForm.name.value = currentUser.name;
        profileForm.email.value = currentUser.email;
        profileForm.phone.value = currentUser.phone;

        profileForm.addEventListener('submit', (e)=>{
            e.preventDefault();
            currentUser.name = profileForm.name.value;
            currentUser.phone = profileForm.phone.value;
            alert('Profile Updated!');
        });
    }

    // Render Destinations (User & Admin)
    if(document.getElementById('destinationsContainer')) renderDestinations(destinations);
    if(document.getElementById('adminDestinationsContainer')) renderAdminDestinations();
});

// ---------------- DESTINATIONS ----------------
function renderDestinations(list){
    const container = document.getElementById('destinationsContainer');
    container.innerHTML = '';
    list.forEach(dest => {
        const card = document.createElement('div');
        card.className = 'destination-card';
        card.innerHTML = `
            <img src="${dest.img}" alt="${dest.name}">
            <div class="card-content">
                <h3>${dest.name}</h3>
                <p>Location: ${dest.location}</p>
                <p>Cost: $${dest.cost}</p>
                <p>Duration: ${dest.duration} Days</p>
            </div>
        `;
        container.appendChild(card);
    });
}

// Filters
function applyFilters(){
    const location = document.getElementById('searchLocation').value.toLowerCase();
    const maxCost = document.getElementById('maxCost').value;
    const duration = document.getElementById('durationFilter').value;
    let filtered = destinations;

    if(location) filtered = filtered.filter(d=> d.location.toLowerCase().includes(location));
    if(maxCost) filtered = filtered.filter(d=> d.cost <= parseInt(maxCost));
    if(duration){
        if(duration=='1') filtered = filtered.filter(d=> d.duration<=3);
        if(duration=='2') filtered = filtered.filter(d=> d.duration>=4 && d.duration<=7);
        if(duration=='3') filtered = filtered.filter(d=> d.duration>=8);
    }
    renderDestinations(filtered);
}

// ---------------- ADMIN PANEL ----------------
function renderAdminDestinations() {
    const container = document.getElementById('adminDestinationsContainer');
    if(!container) return;
    container.innerHTML = '';
    destinations.forEach((dest, index) => {
        const card = document.createElement('div');
        card.className = 'destination-card';
        card.innerHTML = `
            <img src="${dest.img}" alt="${dest.name}">
            <div class="card-content">
                <h3>${dest.name}</h3>
                <p>Location: ${dest.location}</p>
                <p>Cost: $${dest.cost}</p>
                <p>Duration: ${dest.duration} Days</p>
                <button onclick="editDestination(${index})" class="edit-btn">Edit</button>
                <button onclick="deleteDestination(${index})" class="delete-btn">Delete</button>
            </div>
        `;
        container.appendChild(card);
    });
}

// Admin form
const destinationForm = document.getElementById('destinationForm');
if(destinationForm){
    destinationForm.addEventListener('submit', (e)=>{
        e.preventDefault();
        const index = document.getElementById('destIndex').value;
        const dest = {
            name: document.getElementById('destName').value,
            location: document.getElementById('destLocation').value,
            cost: parseInt(document.getElementById('destCost').value),
            duration: parseInt(document.getElementById('destDuration').value),
            img: document.getElementById('destImg').value
        };

        if(index === '') destinations.push(dest);
        else destinations[index] = dest;

        clearForm();
        renderAdminDestinations();
    });
}

function editDestination(index){
    const dest = destinations[index];
    document.getElementById('destIndex').value = index;
    document.getElementById('destName').value = dest.name;
    document.getElementById('destLocation').value = dest.location;
    document.getElementById('destCost').value = dest.cost;
    document.getElementById('destDuration').value = dest.duration;
    document.getElementById('destImg').value = dest.img;
}

function deleteDestination(index){
    if(confirm('Are you sure you want to delete this destination?')){
        destinations.splice(index,1);
        renderAdminDestinations();
    }
}

function clearForm(){
    document.getElementById('destIndex').value = '';
    document.getElementById('destName').value = '';
    document.getElementById('destLocation').value = '';
    document.getElementById('destCost').value = '';
    document.getElementById('destDuration').value = '';
    document.getElementById('destImg').value = '';
}

// ---------------- LOGOUT ----------------
function logout(){
    currentUser = null;
    window.location.href = 'login.html';
}
