<?php
// dbconnect.php - robust connection: try socket then fallback to default host connection
$servername = "localhost";
$username   = "tourism_user";
$password   = "Tourism@123";
$dbname     = "tourism_project";

// Try using XAMPP macOS socket first, then fallback
$socket = "/Applications/XAMPP/xamppfiles/var/mysql/mysql.sock";
$conn = @new mysqli($servername, $username, $password, $dbname, 3306, $socket);

if ($conn && !$conn->connect_error) {
    // connected with socket
} else {
    // fallback: try without specifying socket/port
    $conn = @new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        // final failure - show helpful message
        die("Database connection failed: (" . $conn->connect_errno . ") " . $conn->connect_error . "
Please check that:
 - MySQL server is running in XAMPP
 - The database 'tourism_project' exists
 - The user 'tourism_user' has correct password and privileges
 - If you're on macOS XAMPP and root access issues persist, consider creating a dedicated MySQL user and using that here.
");
    }
}

$conn->set_charset("utf8");
?>