<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($query);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            
            $_SESSION['user_id']     = $user['id'];
            $_SESSION['fullname']    = $user['fullname'];
            $_SESSION['email']       = $user['email'];
            $_SESSION['mobile'] = $user['mobile'];
            $_SESSION['created_at']  = $user['created_at'];

            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "Incorrect password.";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Email not registered.";
        header("Location: login.php");
        exit();
    }
}
$conn->close();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Login | Tourism Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<style>
:root {
  --bg1:#0f4c81;
  --bg2:#007BFF;
  --card: rgba(255,255,255,0.08);
  --accent: rgba(255,255,255,0.12);
  --text: #ffffff;
}
*{box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{
  margin:0;
  min-height:100vh;
  background: linear-gradient(135deg,var(--bg1),var(--bg2));
  display:flex;
  align-items:center;
  justify-content:center;
  padding:32px;
}
.card{
  width:100%;
  max-width:420px;
  background: var(--card);
  border-radius:14px;
  padding:28px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.25);
  backdrop-filter: blur(8px);
  color:var(--text);
}
h1{margin:0 0 12px;font-size:22px;font-weight:600;}
p.subtitle{margin:0 0 20px;opacity:0.95;}
.form-row{margin-bottom:12px;}
input[type="email"], input[type="password"]{
  width:100%;
  padding:12px 14px;
  border-radius:10px;
  border:none;
  background: var(--accent);
  color:#fff;
  outline:none;
  font-size:15px;
}
input::placeholder{
  color:#ddd;              /* 🔹 clearer placeholder */
  opacity:1;
}
input:focus{
  background:rgba(255,255,255,0.18);
  border:1.5px solid #fff;
}
.btn{
  width:100%;
  padding:12px;
  border-radius:10px;
  border:none;
  background: linear-gradient(90deg,#0056d6,#007bff);
  color:white;
  font-weight:600;
  cursor:pointer;
  margin-top:8px;
  font-size:15px;
}
.btn:hover{background:linear-gradient(90deg,#0048b8,#006ee6);}
.muted{font-size:13px;opacity:0.9;margin-top:10px;}
.links{display:flex;justify-content:space-between;align-items:center;margin-top:12px;}
a.link{color:#e8f3ff;text-decoration:underline;}
.msg{
  padding:10px;
  background:rgba(255,255,255,0.1);
  border-radius:8px;
  margin-bottom:12px;
  text-align:center;
}
</style>
</head>
<body>
<div class="card">
  <h1>Login to your account</h1>
  <p class="subtitle">Enter your credentials to access the Tourism Portal.</p>

  <?php
  if(isset($_SESSION['error'])){
      echo '<div class="msg">'.htmlspecialchars($_SESSION['error']).'</div>';
      unset($_SESSION['error']);
  }
  if(isset($_SESSION['success'])){
      echo '<div class="msg">'.htmlspecialchars($_SESSION['success']).'</div>';
      unset($_SESSION['success']);
  }
  ?>

  <form method="post" action="login.php" autocomplete="off">
    <div class="form-row"><input name="email" type="email" placeholder="Email address" required /></div>
    <div class="form-row"><input name="password" type="password" placeholder="Password" required /></div>
    <button class="btn" type="submit">Login</button>

    <div class="links">
      <div class="muted">Don't have an account?</div>
      <a class="link" href="register.php">Register →</a>
    </div>
  </form>
</div>
</body>
</html>
