<?php
session_start();
include('../dbconnect.php');

// Redirect if user not logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to access the dashboard.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user info from session
$fullname   = $_SESSION['fullname'] ?? 'Guest';
$email      = $_SESSION['email'] ?? 'N/A';
$mobile     = $_SESSION['mobile'] ?? 'N/A';
$created_at = isset($_SESSION['created_at']) ? date("d M Y", strtotime($_SESSION['created_at'])) : 'N/A';

// Fetch user’s booking history
$stmt = $conn->prepare("SELECT b.id, b.destination, b.start_date, b.price, b.status, 
                               p.method, p.txn_id, p.status AS pay_status
                        FROM bookings b
                        LEFT JOIN payments p ON b.id = p.booking_id
                        WHERE b.user_id = ?
                        ORDER BY b.id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Dashboard | Smart Tourist</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background: #f0f2f5;
}
.dashboard-container {
    max-width: 1000px;
    margin: 60px auto;
    padding: 20px;
}
.auth-card {
    background: #fff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    text-align: center;
    transition: transform 0.3s ease;
}
.auth-card:hover {
    transform: translateY(-5px);
}
.auth-card h2 {
    color: #0078ff;
    margin-bottom: 20px;
}
.user-info {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    margin: 25px 0;
}
.user-info div {
    width: 45%;
    margin-bottom: 15px;
    text-align: left;
}
.user-info div i {
    color: #0078ff;
    margin-right: 8px;
}
.dashboard-btn {
    display: inline-block;
    padding: 12px 25px;
    margin: 10px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s ease;
}
.dashboard-btn.explore {
    background: #0078ff;
    color: #fff;
}
.dashboard-btn.explore:hover {
    background: #005fd4;
}
.dashboard-btn.logout {
    background: #e74c3c;
    color: #fff;
}
.dashboard-btn.logout:hover {
    background: #c0392b;
}
.history {
    background: #fff;
    border-radius: 12px;
    padding: 25px;
    margin-top: 30px;
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
}
.history h3 {
    color: #0078ff;
    text-align: center;
    margin-bottom: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
}
th, td {
    padding: 10px 15px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}
th {
    background: #0078ff;
    color: white;
}
.status {
    padding: 5px 10px;
    border-radius: 8px;
    font-weight: 500;
}
.status.confirmed {
    background: #d4edda;
    color: #155724;
}
.status.pending {
    background: #fff3cd;
    color: #856404;
}
footer {
    background: #111;
    color: white;
    text-align: center;
    padding: 15px;
    margin-top: 50px;
    font-size: 0.9rem;
}
@media (max-width: 600px) {
    .user-info div {
        width: 100%;
    }
    table {
        font-size: 0.8rem;
    }
}
</style>
</head>
<body>

<div class="dashboard-container">
    <div class="auth-card">
        <h2>Welcome, <?php echo htmlspecialchars($fullname); ?>!</h2>

        <div class="user-info">
            <div><i class="fa fa-user"></i><strong>Full Name:</strong> <?php echo htmlspecialchars($fullname); ?></div>
            <div><i class="fa fa-envelope"></i><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></div>
            <div><i class="fa fa-phone"></i><strong>Phone:</strong> <?php echo htmlspecialchars($mobile); ?></div>
            <div><i class="fa fa-calendar"></i><strong>Member Since:</strong> <?php echo $created_at; ?></div>
        </div>

        <a href="../destination/view_destination.html" class="dashboard-btn explore">
            <i class="fa fa-map-marked-alt"></i> Explore Destinations
        </a>
        <a href="../feedback/feedback.php" class="dashboard-btn" style="background:#2ecc71;">
        <i class="fa fa-comment-dots"></i> Feedback
        </a>

        <a href="logout.php" class="dashboard-btn logout">
            <i class="fa fa-sign-out-alt"></i> Logout
        </a>

    </div>

    <div class="history">
        <h3><i class="fa fa-history"></i> Booking History</h3>
        <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Destination</th>
                <th>Date</th>
                <th>Price</th>
                <th>Booking Status</th>
                <th>Payment Method</th>
                <th>Transaction ID</th>
                <th>Payment Status</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td>#<?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['destination']) ?></td>
                <td><?= htmlspecialchars($row['start_date']) ?></td>
                <td>₹<?= number_format($row['price'], 2) ?></td>
                <td><span class="status <?= strtolower($row['status']) ?>"><?= ucfirst($row['status']) ?></span></td>
                <td><?= $row['method'] ?? 'N/A' ?></td>
                <td><?= $row['txn_id'] ?? 'N/A' ?></td>
                <td><?= $row['pay_status'] ?? 'Pending' ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <?php else: ?>
        <p style="text-align:center;color:#888;">No bookings found yet.</p>
        <?php endif; ?>
    </div>
</div>

<footer>© 2025 Smart Tourist Management System | Developed by <b>Srishti Nautiyal</b></footer>

</body>
</html>
