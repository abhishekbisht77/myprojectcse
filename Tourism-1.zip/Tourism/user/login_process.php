<?php
session_start();
include '../dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $_SESSION['error'] = "Please enter email and password.";
        header("Location: login.php");
        exit;
    }

    // Prepare SQL
    $stmt = $conn->prepare("SELECT id, fullname, email, mobile, password, created_at FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        $_SESSION['error'] = "Email not registered.";
        $stmt->close();
        header("Location: login.php");
        exit;
    }

    $stmt->bind_result($id, $fullname, $email_db, $mobile, $hash, $created_at);
    $stmt->fetch();
    $stmt->close();

    if (password_verify($password, $hash)) {
    // Fetch full user info
    $details_stmt = $conn->prepare("SELECT fullname, email, mobile, created_at FROM users WHERE id = ?");
    $details_stmt->bind_param("i", $id);
    $details_stmt->execute();
    $result = $details_stmt->get_result();
    $user = $result->fetch_assoc();
    $details_stmt->close();

    // Save full data in session
    $_SESSION['user_id'] = $id;
    $_SESSION['fullname'] = $user['fullname'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['mobile'] = $user['mobile'];
    $_SESSION['created_at'] = $user['created_at'];

    header("Location: dashboard.php");
    exit;
}

}

header("Location: login.php");
exit;
?>
