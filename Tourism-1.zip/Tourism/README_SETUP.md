
Tourism Project - Setup Guide (XAMPP macOS)

1. MySQL user & database
   - Recommended: create a dedicated user and database, then import SQL.
   - Example (run in terminal or phpMyAdmin):
     CREATE DATABASE IF NOT EXISTS tourism_project CHARACTER SET utf8 COLLATE utf8_general_ci;
     CREATE USER 'tourism_user'@'localhost' IDENTIFIED BY 'Tourism@123';
     GRANT ALL PRIVILEGES ON tourism_project.* TO 'tourism_user'@'localhost';
     FLUSH PRIVILEGES;

2. Create users table (if not imported)
   -- users table SQL:
   CREATE TABLE IF NOT EXISTS users (
     id INT AUTO_INCREMENT PRIMARY KEY,
     fullname VARCHAR(100) NOT NULL,
     mobile VARCHAR(20),
     email VARCHAR(100) NOT NULL UNIQUE,
     password VARCHAR(255) NOT NULL,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );

3. Files and paths
   - dbconnect.php is at project root (Tourism/dbconnect.php)
   - All user pages are in Tourism/user/
   - register.php posts to register_process.php (relative paths used)

4. Common fixes
   - If you get Access denied or 1698 errors on macOS, either:
     * Use phpMyAdmin to create 'tourism_user' user and assign privileges; or
     * Reconfigure MySQL authentication plugin for the user to mysql_native_password.

5. Testing connection
   - Open browser: http://localhost/Tourism/test.php
   - You should see "Connected successfully as tourism_user!" if DB is accessible.

6. Further help
   - If registration redirects to blank page, enable display_errors in PHP or check Apache/XAMPP error logs.


Admin default: admin@tourism.com / admin123

