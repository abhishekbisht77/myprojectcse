<?php
session_start();

// If user is logged in → go to user dashboard
if (isset($_SESSION['email'])) {
    header("Location: user/dashboard.php");
    exit;
}

// Otherwise → open the main homepage (HTML version)
header("Location: index.html");
exit;
?>
