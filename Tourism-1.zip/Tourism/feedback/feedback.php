<?php
session_start();
include('../dbconnect.php');


if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to give feedback.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Feedback | Smart Tourist</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="feedback.css">
</head>
<body>
  <div class="feedback-container">
    <h2>We Value Your Feedback 🌍</h2>
    <form id="feedbackForm" action="../feedback/feedback_process.php" method="POST">
      <label for="rating">Your Rating:</label>
      <div class="stars" id="starContainer">
        <span class="star" data-value="1">&#9733;</span>
        <span class="star" data-value="2">&#9733;</span>
        <span class="star" data-value="3">&#9733;</span>
        <span class="star" data-value="4">&#9733;</span>
        <span class="star" data-value="5">&#9733;</span>
      </div>
      <input type="hidden" id="rating" name="rating" required>

      <label for="comment">Your Comment:</label>
      <textarea id="comment" name="comment" rows="4" placeholder="Write your feedback..." required></textarea>

      <button type="submit" id="submitBtn">Submit Feedback</button>
    </form>

    <?php if (isset($_SESSION['feedback_msg'])): ?>
      <p style="margin-top:15px; color:limegreen;">
        <?= $_SESSION['feedback_msg']; unset($_SESSION['feedback_msg']); ?>
      </p>
    <?php endif; ?>
  </div>

  <script>
  
    const stars = document.querySelectorAll('.star');
    const ratingInput = document.getElementById('rating');
    const form = document.getElementById('feedbackForm');

    stars.forEach(star => {
      star.addEventListener('click', () => {
        const rating = star.getAttribute('data-value');
        ratingInput.value = rating;

        stars.forEach(s => s.classList.remove('selected'));
        star.classList.add('selected');
      });
    });

    
    form.addEventListener('submit', (e) => {
      if (!ratingInput.value) {
        e.preventDefault();
        alert("Please select a rating before submitting!");
      } else {
        // Let the form submit normally
        form.submit();
      }
    });
  </script>
</body>
</html>
