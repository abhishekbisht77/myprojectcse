document.addEventListener("DOMContentLoaded", () => {
  const stars = document.querySelectorAll(".star");
  const ratingInput = document.getElementById("rating");
  const form = document.getElementById("feedbackForm");

  if (!form || !stars.length) return;

  stars.forEach((star, index) => {
    star.addEventListener("click", () => {
      const ratingValue = index + 1;
      ratingInput.value = ratingValue;

      stars.forEach((s, i) => {
        if (i < ratingValue) {
          s.classList.add("selected");
        } else {
          s.classList.remove("selected");
        }
      });
    });

    // Hover preview
    star.addEventListener("mouseover", () => {
      stars.forEach((s, i) => {
        s.classList.toggle("hovered", i <= index);
      });
    });

    star.addEventListener("mouseout", () => {
      stars.forEach((s) => s.classList.remove("hovered"));
    });
  });

  // Prevent empty rating submission
  form.addEventListener("submit", (e) => {
    if (!ratingInput.value) {
      e.preventDefault();
      alert("Please select a star rating before submitting!");
    }
  });
});
