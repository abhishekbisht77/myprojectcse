<?php
session_start();
include('../dbconnect.php'); 


if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to give feedback.";
    header("Location: ../user/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
$comment = trim($_POST['comment'] ?? '');

if ($rating < 1 || $rating > 5 || empty($comment)) {
    $_SESSION['feedback_msg'] = "⚠️ Please provide a valid rating and comment.";
    header("Location: ../user/feedback.php");
    exit();
}


$stmt = $conn->prepare("INSERT INTO feedback (user_id, rating, comment) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $user_id, $rating, $comment);

if ($stmt->execute()) {
    $_SESSION['feedback_msg'] = "✅ Thank you for your feedback!";
} else {
    $_SESSION['feedback_msg'] = "❌ Error submitting feedback. Please try again.";
}

$stmt->close();
$conn->close();


header("Location: ../feedback/feedback.php");
exit();
?>
