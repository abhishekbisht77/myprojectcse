<?php
session_start();

// Logged-in user info
$user_name = isset($_SESSION['fullname']) ? urlencode($_SESSION['fullname']) : '';
$user_email = isset($_SESSION['email']) ? urlencode($_SESSION['email']) : '';

$destinations = [
    ["name"=>"Goa Beach Adventure", "location"=>"Goa", "image"=>"goa.jpg", "page"=>"goa.html", "booking"=>"goa_booking.php"],
    ["name"=>"Delhi Heritage Tour", "location"=>"Delhi", "image"=>"delhi.jpg", "page"=>"delhi.html", "booking"=>"delhi_booking.php"],
    ["name"=>"Sikkim Delight", "location"=>"Sikkim", "image"=>"sikkim.jpg", "page"=>"sikkim.html", "booking"=>"sikkim_booking.php"],
    ["name"=>"Hyderabad Culture Trip", "location"=>"Hyderabad", "image"=>"hyderabad.jpg", "page"=>"hyderabad.html", "booking"=>"hyderabad_booking.php"],
    ["name"=>"Agra Taj Mahal Tour", "location"=>"Agra", "image"=>"agra.jpg", "page"=>"agra.html", "booking"=>"agra_booking.php"],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>View Destinations - Smart Tourist Management System</title>
  <link rel="stylesheet" href="../assets/style.css" />
  <style>
    body { font-family: 'Poppins', sans-serif; background:#f4f8fb; margin:0; padding:0;}
    header { background:#0078ff; color:white; text-align:center; padding:20px; font-size:1.6rem; font-weight:600; }
    .container { max-width:1200px; margin:40px auto; padding:20px; }
    h2 { text-align:center; color:#0078ff; font-size:2rem; margin-bottom:30px; }
    .destinations { display:flex; flex-wrap:wrap; gap:25px; justify-content:center; }
    .card { background:#fff; border-radius:15px; width:280px; box-shadow:0 6px 15px rgba(0,0,0,0.1); transition:transform 0.3s ease; overflow:hidden; text-decoration:none; color:inherit; }
    .card:hover { transform:translateY(-5px); }
    .card img { width:100%; height:180px; object-fit:cover; }
    .card-content { padding:15px; text-align:left; }
    .card-content h3 { color:#0078ff; font-size:1.3rem; margin-bottom:10px; }
    .card-content p { font-size:0.95rem; color:#555; margin:5px 0; }
    .book-btn {
      display:block;
      margin-top:10px;
      padding:8px 0;
      text-align:center;
      background:#0078ff;
      color:#fff;
      border-radius:5px;
      text-decoration:none;
      font-weight:500;
      transition:background 0.3s;
    }
    .book-btn:hover { background:#005fd4; }
    footer { background:#111; color:white; text-align:center; padding:15px; font-size:0.9rem; margin-top:50px; }
  </style>
</head>

<body>
<header>View Destinations</header>

<div class="container">
  <h2>Popular Destinations</h2>
  <div class="destinations">

    <?php foreach($destinations as $dest): ?>
      <div class="card">
        <a href="<?php echo $dest['page']; ?>">
          <img src="../assets/images/<?php echo $dest['image']; ?>" alt="<?php echo $dest['name']; ?>">
        </a>
        <div class="card-content">
          <h3><?php echo $dest['name']; ?></h3>
          <p><b>Location:</b> <?php echo $dest['location']; ?></p>
          <!-- Book Now button with user info -->
          <a href="<?php echo $dest['booking']; ?>?name=<?php echo $user_name; ?>&email=<?php echo $user_email; ?>" class="book-btn">Book Now</a>
        </div>
      </div>
    <?php endforeach; ?>

  </div>
</div>

<footer>© 2025 Smart Tourist Management System | Developed by <b>Srishti Nautiyal</b></footer>
</body>
</html>
