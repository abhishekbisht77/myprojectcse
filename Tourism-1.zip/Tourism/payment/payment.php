<?php
session_start();
include('../dbconnect.php');

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check booking ID
$booking_id = $_GET['booking_id'] ?? 0;
if (!$booking_id) {
    die("<h3 style='color:red;text-align:center;'>Invalid booking ID.</h3>");
}

// Fetch booking details
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
if (!$booking) {
    die("<h3 style='color:red;text-align:center;'>Booking not found.</h3>");
}

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $method = $_POST['method'] ?? '';
    $upi_id = $_POST['upi_id'] ?? '';
    $card_no = $_POST['card_no'] ?? '';
    $amount = $booking['price'];
    $txn_id = "TXN" . rand(100000, 999999);
    $status = 'Success';

    // Simple validation
    if ($method == 'UPI' && empty($upi_id)) {
        $error = "Please enter your UPI ID.";
    } elseif ($method == 'Card' && empty($card_no)) {
        $error = "Please enter your card number.";
    } else {
        // Insert payment record
        $stmt2 = $conn->prepare("INSERT INTO payments (booking_id, amount, method, status, txn_id) VALUES (?, ?, ?, ?, ?)");
        $stmt2->bind_param("idsss", $booking_id, $amount, $method, $status, $txn_id);
        $stmt2->execute();

        // Update booking status
        $conn->query("UPDATE bookings SET status='confirmed' WHERE id=" . $booking_id);

        // Redirect to confirmation
        header("Location: ../booking/confirmation.php?booking_id=" . $booking_id);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment - Smart Tourist Management</title>
<link rel="stylesheet" href="../assets/style.css">
<style>
body {
    font-family:'Poppins', sans-serif;
    background:#f4f8fb;
    margin:0;
    padding:0;
}
header {
    background:#0078ff;
    color:#fff;
    text-align:center;
    padding:20px;
    font-size:1.5rem;
    font-weight:600;
}
.container {
    max-width:600px;
    margin:40px auto;
    background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 6px 15px rgba(0,0,0,0.1);
}
h2 {
    text-align:center;
    color:#0078ff;
}
label {
    display:block;
    margin-top:15px;
    font-weight:500;
}
input, select {
    width:100%;
    padding:10px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:1rem;
    margin-top:5px;
}
button {
    margin-top:25px;
    width:100%;
    padding:12px;
    background:#0078ff;
    color:white;
    border:none;
    border-radius:10px;
    font-weight:500;
    cursor:pointer;
    transition:0.3s;
}
button:hover {
    background:#005fd4;
}
.details {
    background:#f9f9f9;
    padding:15px;
    border-radius:10px;
    margin-bottom:20px;
    border-left:4px solid #0078ff;
}
.total {
    font-weight:600;
    color:#28a745;
    margin-top:10px;
}
.error {
    color:red;
    text-align:center;
    font-weight:bold;
    margin-bottom:10px;
}
footer {
    background:#111;
    color:white;
    text-align:center;
    padding:15px;
    margin-top:50px;
    font-size:0.9rem;
}
.hidden {
    display:none;
}
</style>
</head>
<body>

<header>Complete Your Payment</header>

<div class="container">
    <h2>Payment for Your Trip</h2>

    <?php if (!empty($error)): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <div class="details">
        <p><b>Destination:</b> <?= htmlspecialchars($booking['destination']) ?></p>
        <p><b>Travel Date:</b> <?= htmlspecialchars($booking['start_date']) ?></p>
        <p><b>Total Amount:</b> ₹<?= number_format($booking['price'], 2) ?></p>
    </div>

    <form method="post">
        <label for="method">Select Payment Method:</label>
        <select id="method" name="method" required>
            <option value="UPI" <?= (isset($_POST['method']) && $_POST['method'] == 'UPI') ? 'selected' : '' ?>>UPI</option>
            <option value="Card" <?= (isset($_POST['method']) && $_POST['method'] == 'Card') ? 'selected' : '' ?>>Card</option>
        </select>

        <div id="upiField" class="method-field">
            <label for="upi_id">Enter UPI ID</label>
            <input type="text" name="upi_id" id="upi_id" placeholder="e.g. srishti@upi">
        </div>

        <div id="cardField" class="method-field hidden">
            <label for="card_no">Enter Card Number</label>
            <input type="text" name="card_no" id="card_no" maxlength="16" placeholder="e.g. 1234 5678 9012 3456">
        </div>

        <button type="submit">Pay Now</button>
    </form>
</div>

<footer>© 2025 Smart Tourist Management System | Developed by <b>Srishti Nautiyal</b></footer>

<script>
const methodSelect = document.getElementById('method');
const upiField = document.getElementById('upiField');
const cardField = document.getElementById('cardField');

function toggleFields() {
    if (methodSelect.value === 'UPI') {
        upiField.classList.remove('hidden');
        cardField.classList.add('hidden');
    } else {
        cardField.classList.remove('hidden');
        upiField.classList.add('hidden');
    }
}
methodSelect.addEventListener('change', toggleFields);
toggleFields();
</script>

</body>
</html>
