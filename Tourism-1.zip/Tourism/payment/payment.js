document.getElementById('paymentForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const amount = document.getElementById('amount').value.trim();
  const method = document.getElementById('method').value;
  const details = document.getElementById('details').value.trim();
  const resultDiv = document.getElementById('paymentResult');

  if (!amount || !method || !details) {
    alert("Please fill out all the fields.");
    return;
  }

  // Format date/time
  const now = new Date();
  const timeString = now.toLocaleString();

  // Show submitted data
  resultDiv.innerHTML = `
    <h3>✅ Payment Successful</h3>
    <p><strong>Amount:</strong> ₹${amount}</p>
    <p><strong>Payment Method:</strong> ${method}</p>
    <p><strong>Details:</strong> ${details}</p>
    <p><strong>Submitted At:</strong> ${timeString}</p>
  `;

  resultDiv.classList.remove('hidden');

  // Reset form
  this.reset();
});
