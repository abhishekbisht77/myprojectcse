<?php
// Start session if not already started
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

// Include database connection
include(__DIR__ . '/../dbconnect.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tourism Management System</title>
<link rel="stylesheet" href="../style.css">
</head>
<body>
<header>
    <h1>Smart Tourism Management</h1>
    <nav>
        <a href="../register.php">Register</a>
        <a href="../login.php">Login</a>
        <a href="../destinations.php">Destinations</a>
        <?php if(isset($_SESSION['admin_email'])): ?>
            <a href="../admin/admin_dashboard.php">Admin Dashboard</a>
        <?php endif; ?>
    </nav>
</header>
