<footer>
    <p>© 2025 Tourism Management System. All Rights Reserved.</p>
</footer>
</body>
</html>
