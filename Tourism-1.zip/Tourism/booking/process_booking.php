<?php
session_start();
include('../dbconnect.php');

// Check login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to book a trip.";
    header("Location: ../user/login.php");
    exit();
}

// Get POST data safely
$user_id = $_SESSION['user_id'];
$fullname = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$destination = $_POST['destination'] ?? '';
$adults = intval($_POST['adult'] ?? 0);
$children = intval($_POST['children'] ?? 0);
$senior = intval($_POST['senior'] ?? 0);
$start_date = $_POST['date'] ?? '';

// Get base price from destinations
$result = $conn->query("SELECT price FROM destinations WHERE name = '{$destination}' LIMIT 1");
$row = $result->fetch_assoc();
$basePrice = $row['price'] ?? 0;

// Calculate total price
$total_price = $adults*$basePrice + $senior*$basePrice*0.9 + $children*$basePrice*0.7;

// Prepare statement
$stmt = $conn->prepare("INSERT INTO bookings (user_id, fullname, email, phone, destination, start_date, price) VALUES (?, ?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

// Bind params and execute
$stmt->bind_param("isssssd", $user_id, $fullname, $email, $phone, $destination, $start_date, $total_price);

if ($stmt->execute()) {
    // Redirect to confirmation
    $booking_id = $stmt->insert_id;
    header("Location: confirmation.php?booking_id=" . $booking_id);
    exit();
} else {
    echo "Booking failed: " . $stmt->error;
}
?>
