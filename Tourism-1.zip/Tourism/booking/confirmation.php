<?php
session_start();
include('../dbconnect.php');

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Get booking ID
$booking_id = $_GET['booking_id'] ?? 0;
if (!$booking_id) {
    die("<h3 style='text-align:center;color:red;'>Invalid booking ID.</h3>");
}

// Fetch booking details
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();

if (!$booking) {
    die("<h3 style='text-align:center;color:red;'>Booking not found.</h3>");
}

// Fetch payment info if exists
$stmt2 = $conn->prepare("SELECT * FROM payments WHERE booking_id = ?");
$stmt2->bind_param("i", $booking_id);
$stmt2->execute();
$payment = $stmt2->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Confirmation</title>
<link rel="stylesheet" href="../assets/style.css">
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: #f4f8fb;
    margin: 0;
    padding: 0;
}
header {
    background: #0078ff;
    color: #fff;
    text-align: center;
    padding: 20px;
    font-size: 1.6rem;
    font-weight: 600;
}
.container {
    max-width: 700px;
    margin: 40px auto;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    padding: 30px;
}
h2 {
    text-align: center;
    color: #0078ff;
    margin-bottom: 20px;
}
.info {
    line-height: 1.8;
    font-size: 1rem;
    color: #333;
}
.highlight {
    color: #0078ff;
    font-weight: 600;
}
.status {
    text-align: center;
    padding: 10px;
    font-weight: bold;
    border-radius: 10px;
    margin-bottom: 20px;
}
.status.success {
    background: #d4edda;
    color: #155724;
}
.status.pending {
    background: #fff3cd;
    color: #856404;
}
button {
    display: block;
    margin: 20px auto;
    background: #0078ff;
    color: white;
    border: none;
    border-radius: 10px;
    padding: 12px 25px;
    cursor: pointer;
    font-size: 1rem;
    transition: 0.3s;
}
button:hover {
    background: #005fd4;
}
footer {
    background: #111;
    color: white;
    text-align: center;
    padding: 15px;
    margin-top: 50px;
    font-size: 0.9rem;
}
</style>
</head>
<body>

<header>Booking Confirmation</header>

<div class="container">
    <h2>🎉 Your Booking is Confirmed!</h2>

    <div class="status <?php echo ($booking['status'] == 'confirmed' || ($payment && $payment['status'] == 'Success')) ? 'success' : 'pending'; ?>">
        <?php
        if ($payment && $payment['status'] == 'Success') {
            echo "Payment Successful ✅";
        } else {
            echo "Payment Pending ⏳";
        }
        ?>
    </div>

    <div class="info">
        <p><b>Booking ID:</b> <span class="highlight">#<?php echo $booking['id']; ?></span></p>
        <p><b>Name:</b> <?php echo htmlspecialchars($booking['fullname']); ?></p>
        <p><b>Email:</b> <?php echo htmlspecialchars($booking['email']); ?></p>
        <p><b>Phone:</b> <?php echo htmlspecialchars($booking['phone']); ?></p>
        <p><b>Destination:</b> <?php echo htmlspecialchars($booking['destination']); ?></p>
        <p><b>Travel Date:</b> <?php echo htmlspecialchars($booking['start_date']); ?></p>
        <p><b>Total Price:</b> ₹<?php echo number_format($booking['price'], 2); ?></p>
    </div>

    <?php if ($payment): ?>
    <hr style="margin:20px 0;">
    <h3 style="text-align:center;color:#0078ff;">💳 Payment Details</h3>
    <div class="info">
        <p><b>Payment Method:</b> <?php echo htmlspecialchars($payment['method']); ?></p>
        <p><b>Transaction ID:</b> <?php echo htmlspecialchars($payment['txn_id']); ?></p>
        <p><b>Status:</b> <?php echo htmlspecialchars($payment['status']); ?></p>
        <p><b>Amount Paid:</b> ₹<?php echo number_format($payment['amount'], 2); ?></p>
    </div>
    <?php endif; ?>

    <button onclick="window.location.href='../user/dashboard.php'">← Back to Dashboard</button>
</div>

<footer>© 2025 Smart Tourist Management System | Developed by <b>Srishti Nautiyal</b></footer>

</body>
</html>
