<?php
session_start();
include('../dbconnect.php');

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to book a trip.";
    header("Location: ../user/login.php");
    exit();
}

// Fetch destinations
$destinations = [];
$result = $conn->query("SELECT name, price FROM destinations");
while ($row = $result->fetch_assoc()) {
    $destinations[$row['name']] = $row['price'];
}

// Default values
$destination = $_GET['destination'] ?? 'Goa';
$user_name = $_SESSION['fullname'] ?? '';
$user_email = $_SESSION['email'] ?? '';
$error = "";

// Handle booking submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $fullname = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $destination = $_POST['destination'];
    $adults = intval($_POST['adult']);
    $seniors = intval($_POST['senior']);
    $children = intval($_POST['children']);
    $travel_date = $_POST['date'];

    // Validate destination exists
    if (!isset($destinations[$destination])) {
        $error = "Invalid destination selected.";
    } else {
        $basePrice = $destinations[$destination];
        $total_price = $adults * $basePrice + $seniors * $basePrice * 0.9 + $children * $basePrice * 0.7;

        // Insert booking
        $stmt = $conn->prepare("INSERT INTO bookings (user_id, fullname, email, phone, destination, start_date, end_date, price) VALUES (?, ?, ?, ?, ?, ?, NULL, ?)");
        $stmt->bind_param("isssssd", $user_id, $fullname, $email, $phone, $destination, $travel_date, $total_price);

        if ($stmt->execute()) {
            $booking_id = $stmt->insert_id;
            header("Location: ../payment/payment.php?booking_id=" . $booking_id);
            exit();
        } else {
            echo "<h3 style='color:red;text-align:center;'>Booking failed: " . $stmt->error . "</h3>";
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Book Your Trip</title>
<link rel="stylesheet" href="../assets/style.css">
<style>
body {
    font-family:'Poppins', sans-serif;
    background:#f4f8fb;
    margin:0;
    padding:0;
}
header {
    background:#0078ff;
    color:#fff;
    text-align:center;
    padding:20px;
    font-size:1.5rem;
    font-weight:600;
}
.container {
    max-width:600px;
    margin:40px auto;
    padding:20px;
    background:white;
    border-radius:15px;
    box-shadow:0 6px 15px rgba(0,0,0,0.1);
}
h2 {
    color:#0078ff;
    text-align:center;
    margin-bottom:20px;
}
form {
    display:flex;
    flex-direction:column;
    gap:15px;
}
label {
    font-weight:500;
}
input, select {
    padding:10px;
    border-radius:8px;
    border:1px solid #ccc;
    font-size:1rem;
    width:100%;
}
button {
    padding:12px;
    background:#0078ff;
    color:white;
    border:none;
    border-radius:10px;
    font-weight:500;
    cursor:pointer;
    transition:0.3s;
}
button:hover {
    background:#005fd4;
}
.total {
    font-weight:600;
    color:#2ecc71;
    margin-top:10px;
}
.error {
    color:red;
    font-weight:bold;
    text-align:center;
    margin-bottom:15px;
}
footer {
    background:#111;
    color:white;
    text-align:center;
    padding:15px;
    margin-top:50px;
    font-size:0.9rem;
}
</style>
</head>
<body>

<header>Book Your Trip</header>

<div class="container">
    <h2>Trip Booking Form</h2>
    <?php if(isset($error) && $error != "") echo "<p class='error'>$error</p>"; ?>

    <form id="bookingForm" method="post" action="">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user_name); ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_email); ?>" required>

        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" required>

        <label for="destination">Destination</label>
        <select id="destination" name="destination" required>
            <?php foreach($destinations as $dest_name => $price): ?>
                <option value="<?php echo htmlspecialchars($dest_name); ?>" <?php echo ($dest_name==$destination)?'selected':''; ?>>
                    <?php echo htmlspecialchars($dest_name); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Guests</label>
        <input type="number" id="adult" name="adult" min="0" value="1" placeholder="Number of Adults" required>
        <input type="number" id="senior" name="senior" min="0" value="0" placeholder="Number of Senior Citizens">
        <input type="number" id="children" name="children" min="0" value="0" placeholder="Number of Children">

        <p class="total" id="totalPrice">Total Price: ₹0</p>

        <label for="date">Travel Date</label>
        <input type="date" id="date" name="date" required>

        <button type="submit">Confirm Booking</button>
    </form>
</div>

<footer>© 2025 Smart Tourist Management System | Developed by <b>Srishti Nautiyal</b></footer>

<script>
const prices = <?php echo json_encode($destinations); ?>;
const adultInput = document.getElementById('adult');
const seniorInput = document.getElementById('senior');
const childrenInput = document.getElementById('children');
const destinationSelect = document.getElementById('destination');
const totalPriceEl = document.getElementById('totalPrice');

function updateTotal() {
    const dest = destinationSelect.value;
    const adult = parseInt(adultInput.value) || 0;
    const senior = parseInt(seniorInput.value) || 0;
    const children = parseInt(childrenInput.value) || 0;
    const basePrice = prices[dest];
    const total = adult * basePrice + senior * basePrice * 0.9 + children * basePrice * 0.7;
    totalPriceEl.textContent = "Total Price: ₹" + total;
}

adultInput.addEventListener('input', updateTotal);
seniorInput.addEventListener('input', updateTotal);
childrenInput.addEventListener('input', updateTotal);
destinationSelect.addEventListener('change', updateTotal);
updateTotal();
</script>

</body>
</html>
